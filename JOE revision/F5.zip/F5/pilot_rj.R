# RJMCMC (rj_sampler.R) on the three data sets and on designs from Appendix D, for comparison with SFM and the telescoping
# sampler (pilot_tele.R). Target: static MFM, K - 1 ~ BNB(1, 4, 3), gamma ~ Gamma(1, 200) (same as telescoping "tss").
# Real data: 4 chains, 50,000 + 50,000, same starting values as pilot_real.R. Designs G1, G4, G5, G6, G7 (n = 2,000),
# data sets 1-3, chain 1, 50,000 + 50,000. Usage: Rscript pilot_rj.R <workers> [test]
S <- Sys.getenv("PILOT_R1_DIR", unset = getwd())
a <- commandArgs(TRUE); workers <- as.integer(a[1]); test <- length(a) > 1
res <- file.path(S, if (test) "res_rj_test" else "res_rj"); dir.create(res, showWarnings = FALSE)
setup <- function() { source(file.path(S, "snb_s2_sampler.R")); source(file.path(S, "s2_functions.R")); source(file.path(S, "NB_Comparisons.R"))
  source(file.path(S, "tele_sampler.R")); source(file.path(S, "rj_sampler.R")); invisible(NULL) }
rj_task <- function(tk) {
  f <- file.path(res, sprintf("%s_r%d_rj_c%d.rds", tk$data, tk$rep, tk$chain)); if (file.exists(f)) return(f)
  if (tk$data %in% names(DESIGNS)) { g <- match(tk$data, names(DESIGNS)); set.seed(data_seed(g, 2000, tk$rep)); y <- DESIGNS[[g]]$sim(2000); tm <- DESIGNS[[g]]$modes; th <- 25
    seed <- 880000L + 1000L * g + 7L * tk$rep + 1009L * tk$chain
  } else { y <- real_data(tk$data); tm <- integer(0); th <- 5
    seed <- 700000L + 101L * match(tk$data, c("default", "dna", "inflation")) + 1009L * tk$chain + 17L }
  set.seed(seed); ini <- chain_init(y, 10, tk$chain)
  it <- if (test) c(500, 1000) else c(50000, 50000)
  o <- rj_sampler(y, burnin = it[1], nkeep = it[2], Kinit = 10, Kmax = 30, init = ini, seed = seed)
  s <- summarize_chain(o, y, tm, thin = if (test) 5 else th)
  idx <- seq(if (test) 5 else th, length(o$K), by = if (test) 5 else th)
  out <- c(s, list(task = tk, K = o$K[idx], Kplus = o$Kplus[idx], h = o$h[idx], cpu = o$cpu, acc_moves = o$acc_moves, tried = o$tried, true_modes = tm,
                   tv = if (length(tm)) 0.5 * sum(abs(s$pmf - DESIGNS[[match(tk$data, names(DESIGNS))]]$pmf)) else NA))
  tmp <- paste0(f, ".tmp"); saveRDS(out, tmp); file.rename(tmp, f); f
}
setup()
tasks <- list()
for (d in c("inflation", "dna", "default")) for (ch in 1:4) tasks[[length(tasks) + 1]] <- list(data = d, rep = 0L, chain = ch)
for (d in c("G1", "G4", "G5", "G6", "G7")) for (r in 1:3) tasks[[length(tasks) + 1]] <- list(data = d, rep = r, chain = 1L)
if (test) tasks <- tasks[c(1, 5, 9, 13)]
cat(length(tasks), "tasks,", workers, "workers, start", format(Sys.time()), "\n")
library(parallel); cl <- makeCluster(workers)
clusterExport(cl, c("S", "res", "test", "setup", "rj_task")); clusterEvalQ(cl, { setup(); NULL })
out <- parLapplyLB(cl, tasks, function(tk) tryCatch(rj_task(tk), error = function(e) paste("ERROR", tk$data, tk$rep, tk$chain, conditionMessage(e))), chunk.size = 1)
stopCluster(cl); err <- grep("^ERROR", unlist(out), value = TRUE)
cat("finished", format(Sys.time()), "| errors:", length(err), "\n"); if (length(err)) print(err)
