# SFM with J = 20 on the inflation data (stand-in sample): 4 chains, 50,000 + 50,000, same seeds as pilot_real.R.
S <- Sys.getenv("PILOT_R1_DIR", unset = getwd()); res <- file.path(S, "res_sfm20"); dir.create(res, showWarnings = FALSE)
setup <- function() { source(file.path(S, "snb_s2_sampler.R")); source(file.path(S, "s2_functions.R")); source(file.path(S, "NB_Comparisons.R")); invisible(NULL) }
task <- function(ch) { f <- file.path(res, sprintf("inflation_J20_c%d.rds", ch)); if (file.exists(f)) return(f)
  y <- real_data("inflation"); seed <- 700000L + 101L * 3L + 1009L * ch + 17L; set.seed(seed); ini <- chain_init(y, 20, ch)
  o <- nb_sampler(y, J = 20, burnin = 50000, nkeep = 50000, algorithm = "ours", thin = 1, init = ini, seed = seed); o$acc <- o$acc1
  s <- summarize_chain(o, y, integer(0), thin = 5); s$cpu <- o$cpu; saveRDS(s, f); f }
setup(); library(parallel); cl <- makeCluster(4); clusterExport(cl, c("S", "res", "setup", "task")); clusterEvalQ(cl, { setup(); NULL })
print(parLapplyLB(cl, 1:4, function(ch) tryCatch(task(ch), error = function(e) conditionMessage(e)))); stopCluster(cl)
ch <- lapply(1:4, function(c) readRDS(file.path(res, sprintf("inflation_J20_c%d.rds", c)))); L <- unlist(lapply(ch, `[[`, "L"))
pm <- Reduce(`+`, lapply(ch, `[[`, "pr_mode")) / 4; t <- sort(table(L) / length(L), decreasing = TRUE)[1:3]
cat(sprintf("SFM J=20 inflation | Pr(L) %s | modes %s [%s] | WAIC %.1f | Rhat %.2f | ESS log-lik %s, modes %s | K+ median %d | CPU %.0f\n",
  paste(sprintf("%s:%.2f", names(t), t), collapse = " "), paste(which(pm > .5) - 1, collapse = ","), paste(which(pm > .2 & pm <= .5) - 1, collapse = ","),
  mean(sapply(ch, function(x) -2 * (x$lppd - x$pwaic))), split_rhat(lapply(ch, `[[`, "loglik")), paste(round(sapply(ch, function(x) nb_ess(x$loglik))), collapse = "/"),
  paste(round(sapply(ch, function(x) nb_ess(x$L))), collapse = "/"), median(unlist(lapply(ch, `[[`, "K0"))), median(sapply(ch, `[[`, "cpu"))))
