# Reversible jump MCMC (Richardson and Green, 1997) for the mixture of shifted negative binomial distributions.
# Target (same as the static telescoping sampler in tele_sampler.R):
#   K - 1 ~ BNB(1, 4, 3) truncated at Kmax; w | K ~ Dir(gamma, ..., gamma); gamma ~ Gamma(1, rate 200);
#   kappa_j uniform on {0, ..., M}; mu_j ~ U(0, M]; r-tilde_j ~ U(0, 1/2); allocations z_i | w ~ w.
# The weights are kept on the log scale (lw): with gamma near 0.005, empty components have weights far below 1e-300,
# and the Dirichlet density in the birth, death and split ratios depends on them.
# One sweep: (a) random relabelling of the components (valid since the target is label-invariant);
#   (b) allocations; (c) weights; (d) component parameters (as NB_Comparisons.R, "ours"; empty components from the prior);
#   (e) gamma given w; (f) split or merge; (g) birth or death of an empty component.
# Split of component j into (j, K+1); merge of component K+1 into j (the reverse). Birth appends an empty component at K+1;
# death removes component K if it is empty. Labels are randomised in (a), so every pair and every empty component can be reached.
# Split map (dimension matching, aux u ~ Beta(2,2), z, v ~ N(0,1), discrete d >= 0):
#   w1 = w u, w2 = w (1 - u); mu1 = mu e^{s z}, mu2 = mu e^{-s z}; t = logit(2 r-tilde), t1 = t + tau v, t2 = t - tau v;
#   kappa1 = kappa, kappa2 = kappa + d. Observations of j are reallocated with probabilities prop. to w_k f(y | theta_k).
# Jacobian: w * (2 mu s) * (2 tau) * [r1 (1 - 2 r1) r2 (1 - 2 r2)] / [r (1 - 2 r)], with r = r-tilde.
# Requires NB_Comparisons.R (draw_kappa, draw_rtilde, draw_mu) and tele_sampler.R (log_pK).
lse <- function(x) { m <- max(x); m + log(sum(exp(x - m))) }
rj_sampler <- function(y, burnin = 5000, nkeep = 10000, thin = 1, Kinit = 10, Kmax = 30, init = NULL, seed = NULL,
                       s_mu = 0.5, tau = 0.5, p_d0 = 0.3, ptype = "bnb") {
  if (!is.null(seed)) set.seed(seed)
  tab <- table(y); u <- as.numeric(names(tab)); cnt <- as.numeric(tab); m_u <- length(u); M <- max(y); N <- sum(cnt)
  K <- Kinit; kappa <- rep(0, K); rtilde <- rep(1 / 11, K); mu <- rep(max(mean(y), 1), K)
  if (!is.null(init)) { rtilde <- init$rtilde; kappa <- init$kappa }
  lw <- rep(-log(K), K); gam <- 0.005; sd1 <- rep(0.1, K); b1 <- n1 <- rep(0, K)
  nuj <- if (K == 1) matrix(cnt, ncol = 1) else t(sapply(cnt, function(cc) rmultinom(1, cc, rep(1 / K, K))))
  ldnb <- function(v, k, m, rt) ifelse(v >= k, dnbinom(pmax(v - k, 0), size = (1 - rt) / rt, mu = m, log = TRUE), -Inf)
  lprior_th <- function(k, m, rt) if (k < 0 || k > M || m <= 0 || m > M || rt <= 0 || rt >= 0.5) -Inf else -log(M + 1) - log(M) + log(2)
  ldir <- function(lw, g) lgamma(length(lw) * g) - length(lw) * lgamma(g) + (g - 1) * sum(lw)
  rlogdir <- function(a) { lg <- log(rgamma(length(a), a + 1)) + log(runif(length(a))) / a; lg - lse(lg) }   # log of a Dirichlet draw, stable for small a
  bK <- function(K) if (K <= 1) 1 else if (K >= Kmax) 0 else 0.5                         # prob. of proposing split / birth
  lq_d <- function(d, k) { R <- M - k; if (d < 0 || d > R) -Inf else if (R == 0) 0 else if (d == 0) log(p_d0) else log(1 - p_d0) - log(R) }
  r_d <- function(k) { R <- M - k; if (R == 0 || runif(1) < p_d0) 0 else sample.int(R, 1) }
  nst <- floor(nkeep / thin)
  store <- list(mu = matrix(1, nst, Kmax), rtilde = matrix(0.1, nst, Kmax), kappa = matrix(0, nst, Kmax), w = matrix(0, nst, Kmax),
                nj = matrix(0, nst, Kmax), K = rep(NA, nst), Kplus = rep(NA, nst), h = rep(NA, nst))
  acc <- c(split = 0, merge = 0, birth = 0, death = 0); tried <- acc; n_batch <- 0; t0 <- proc.time()
  for (it in 1:(burnin + nkeep)) {
    o <- sample.int(K)                                                                     # (a)
    kappa <- kappa[o]; mu <- mu[o]; rtilde <- rtilde[o]; lw <- lw[o]; nuj <- nuj[, o, drop = FALSE]; sd1 <- sd1[o]; b1 <- b1[o]; n1 <- n1[o]
    lp <- matrix(-Inf, m_u, K)                                                             # (b)
    for (j in 1:K) lp[, j] <- lw[j] + ldnb(u, kappa[j], mu[j], rtilde[j])
    pr <- exp(lp - apply(lp, 1, max)); for (i in 1:m_u) nuj[i, ] <- rmultinom(1, cnt[i], pr[i, ])
    nj <- colSums(nuj)
    lw <- rlogdir(gam + nj)                                                                # (c)
    for (j in 1:K) {                                                                       # (d)
      if (nj[j] == 0) { kappa[j] <- sample.int(M + 1, 1) - 1; mu[j] <- M * (1 - runif(1)); rtilde[j] <- 0.5 * (1 - runif(1)); next }
      act <- nuj[, j] > 0; ua <- u[act]; na <- nuj[act, j]; r <- (1 - rtilde[j]) / rtilde[j]
      s <- draw_kappa(ua, na, kappa[j], mu[j], r, M); kappa[j] <- s$kappa; mu[j] <- s$mu
      s <- draw_rtilde(ua - kappa[j], na, mu[j], rtilde[j], sd1[j]); rtilde[j] <- s$value; b1[j] <- b1[j] + s$acc; n1[j] <- n1[j] + 1
      mu[j] <- draw_mu(ua - kappa[j], na, mu[j], (1 - rtilde[j]) / rtilde[j], M)
    }
    cand <- exp(log(gam) + rnorm(1))                                                       # (e) gamma | w
    lg <- function(gm) dgamma(gm, 1, rate = 200, log = TRUE) + ldir(lw, gm)
    if (log(runif(1)) < lg(cand) - lg(gam) + log(cand) - log(gam)) gam <- cand
    # (f) split or merge
    if (runif(1) < bK(K)) {                                                                # split j into (j, K+1)
      tried["split"] <- tried["split"] + 1
      j <- sample.int(K, 1); uu <- rbeta(1, 2, 2); z <- rnorm(1); v <- rnorm(1); d <- r_d(kappa[j])
      lw1 <- lw[j] + log(uu); lw2 <- lw[j] + log1p(-uu); m1 <- mu[j] * exp(s_mu * z); m2 <- mu[j] * exp(-s_mu * z)
      tt <- qlogis(2 * rtilde[j]); r1 <- plogis(tt + tau * v) / 2; r2 <- plogis(tt - tau * v) / 2; k1 <- kappa[j]; k2 <- kappa[j] + d
      la <- lprior_th(k1, m1, r1) + lprior_th(k2, m2, r2) - lprior_th(kappa[j], mu[j], rtilde[j])
      if (is.finite(la)) {
        f1 <- lw1 + ldnb(u, k1, m1, r1); f2 <- lw2 + ldnb(u, k2, m2, r2); p1 <- 1 / (1 + exp(f2 - f1))
        nn <- nuj[, j]; ok <- !(nn > 0 & !is.finite(f1) & !is.finite(f2))
        if (all(ok)) {
          n1v <- rbinom(m_u, nn, ifelse(is.finite(p1), p1, 0)); n2v <- nn - n1v
          lpalloc <- sum(ifelse(n1v > 0, n1v * log(p1), 0) + ifelse(n2v > 0, n2v * log(1 - p1), 0))
          lold <- sum(ifelse(nn > 0, nn * (lw[j] + ldnb(u, kappa[j], mu[j], rtilde[j])), 0))
          lnew <- sum(ifelse(n1v > 0, n1v * f1, 0) + ifelse(n2v > 0, n2v * f2, 0))
          la <- la + lnew - lold + log_pK(K + 1, ptype, Kmax) - log_pK(K, ptype, Kmax) + ldir(c(lw[-j], lw1, lw2), gam) - ldir(lw, gam) +
            log(1 - bK(K + 1)) - log(bK(K)) - lpalloc - dbeta(uu, 2, 2, log = TRUE) - dnorm(z, log = TRUE) - dnorm(v, log = TRUE) - lq_d(d, kappa[j]) +
            lw[j] + log(2 * mu[j] * s_mu) + log(2 * tau) + log(r1 * (1 - 2 * r1)) + log(r2 * (1 - 2 * r2)) - log(rtilde[j] * (1 - 2 * rtilde[j]))
          if (is.finite(la) && log(runif(1)) < la) {
            acc["split"] <- acc["split"] + 1
            lw[j] <- lw1; mu[j] <- m1; rtilde[j] <- r1; nuj[, j] <- n1v
            lw <- c(lw, lw2); kappa <- c(kappa, k2); mu <- c(mu, m2); rtilde <- c(rtilde, r2); nuj <- cbind(nuj, n2v)
            sd1 <- c(sd1, sd1[j]); b1 <- c(b1, 0); n1 <- c(n1, 0); K <- K + 1
          }
        }
      }
    } else if (K > 1) {                                                                    # merge K into j
      tried["merge"] <- tried["merge"] + 1
      j <- sample.int(K - 1, 1); d <- kappa[K] - kappa[j]
      if (d >= 0) {
        lww <- lse(c(lw[j], lw[K])); uu <- exp(lw[j] - lww); mm <- sqrt(mu[j] * mu[K]); z <- log(mu[j] / mm) / s_mu
        t1 <- qlogis(2 * rtilde[j]); t2 <- qlogis(2 * rtilde[K]); tt <- (t1 + t2) / 2; v <- (t1 - t2) / (2 * tau); rr <- plogis(tt) / 2
        kk <- kappa[j]; la <- lprior_th(kk, mm, rr) - lprior_th(kappa[j], mu[j], rtilde[j]) - lprior_th(kappa[K], mu[K], rtilde[K])
        if (is.finite(la) && uu > 0 && uu < 1) {
          f1 <- lw[j] + ldnb(u, kappa[j], mu[j], rtilde[j]); f2 <- lw[K] + ldnb(u, kappa[K], mu[K], rtilde[K]); p1 <- 1 / (1 + exp(f2 - f1))
          n1v <- nuj[, j]; n2v <- nuj[, K]; nn <- n1v + n2v
          lpalloc <- sum(ifelse(n1v > 0, n1v * log(p1), 0) + ifelse(n2v > 0, n2v * log(1 - p1), 0))
          lnew <- sum(ifelse(nn > 0, nn * (lww + ldnb(u, kk, mm, rr)), 0))
          lold <- sum(ifelse(n1v > 0, n1v * f1, 0) + ifelse(n2v > 0, n2v * f2, 0))
          ls <- lold - lnew + log_pK(K, ptype, Kmax) - log_pK(K - 1, ptype, Kmax) + ldir(lw, gam) - ldir(c(lw[-c(j, K)], lww), gam) - la +
            log(1 - bK(K)) - log(bK(K - 1)) - lpalloc - dbeta(uu, 2, 2, log = TRUE) - dnorm(z, log = TRUE) - dnorm(v, log = TRUE) - lq_d(d, kk) +
            lww + log(2 * mm * s_mu) + log(2 * tau) + log(rtilde[j] * (1 - 2 * rtilde[j])) + log(rtilde[K] * (1 - 2 * rtilde[K])) - log(rr * (1 - 2 * rr))
          if (is.finite(ls) && log(runif(1)) < -ls) {                                      # acceptance = 1 / (split ratio)
            acc["merge"] <- acc["merge"] + 1
            lw[j] <- lww; kappa[j] <- kk; mu[j] <- mm; rtilde[j] <- rr; nuj[, j] <- nn
            lw <- lw[-K]; kappa <- kappa[-K]; mu <- mu[-K]; rtilde <- rtilde[-K]; nuj <- nuj[, -K, drop = FALSE]; sd1 <- sd1[-K]; b1 <- b1[-K]; n1 <- n1[-K]; K <- K - 1
          }
        }
      }
    }
    # (g) birth or death of an empty component; Beta(1, k) density: log k + (k - 1) log(1 - w)
    nj <- colSums(nuj)
    if (runif(1) < bK(K)) {                                                                # birth at K+1
      tried["birth"] <- tried["birth"] + 1
      ws <- rbeta(1, 1, K); l1 <- log1p(-ws); lwn <- c(lw + l1, log(ws))
      la <- log_pK(K + 1, ptype, Kmax) - log_pK(K, ptype, Kmax) + ldir(lwn, gam) - ldir(lw, gam) + N * l1 +
        log(1 - bK(K + 1)) - log(bK(K)) - (log(K) + (K - 1) * l1) + (K - 1) * l1
      if (is.finite(la) && log(runif(1)) < la) {
        acc["birth"] <- acc["birth"] + 1; lw <- lwn; kappa <- c(kappa, sample.int(M + 1, 1) - 1); mu <- c(mu, M * (1 - runif(1))); rtilde <- c(rtilde, 0.5 * (1 - runif(1)))
        nuj <- cbind(nuj, 0); sd1 <- c(sd1, 0.1); b1 <- c(b1, 0); n1 <- c(n1, 0); K <- K + 1
      }
    } else if (K > 1 && nj[K] == 0) {                                                      # death of K (if empty)
      tried["death"] <- tried["death"] + 1
      l1 <- log1p(-exp(lw[K])); lwn <- lw[-K] - l1
      lb <- log_pK(K, ptype, Kmax) - log_pK(K - 1, ptype, Kmax) + ldir(lw, gam) - ldir(lwn, gam) + N * l1 +
        log(1 - bK(K)) - log(bK(K - 1)) - (log(K - 1) + (K - 2) * l1) + (K - 2) * l1
      if (is.finite(lb) && log(runif(1)) < -lb) {
        acc["death"] <- acc["death"] + 1; lw <- lwn; kappa <- kappa[-K]; mu <- mu[-K]; rtilde <- rtilde[-K]; nuj <- nuj[, -K, drop = FALSE]
        sd1 <- sd1[-K]; b1 <- b1[-K]; n1 <- n1[-K]; K <- K - 1
      }
    } else if (K > 1) tried["death"] <- tried["death"] + 1
    if (it <= burnin && it %% 50 == 0) {
      n_batch <- n_batch + 1; dl <- min(0.1, 1 / sqrt(n_batch))
      for (j in seq_len(K)) if (n1[j] > 0) { rt <- b1[j] / n1[j]; if (rt > 0.4) sd1[j] <- sd1[j] * exp(dl) else if (rt < 0.3) sd1[j] <- sd1[j] * exp(-dl) }
      b1[] <- 0; n1[] <- 0
    }
    if (it > burnin && (it - burnin) %% thin == 0) {
      i <- (it - burnin) / thin; nj <- colSums(nuj); f <- which(nj > 0); kk <- seq_along(f)
      store$mu[i, kk] <- mu[f]; store$rtilde[i, kk] <- rtilde[f]; store$kappa[i, kk] <- kappa[f]; store$w[i, kk] <- exp(lw[f] - lse(lw[f]))
      store$nj[i, kk] <- nj[f]; store$K[i] <- K; store$Kplus[i] <- length(f); store$h[i] <- gam
    }
  }
  tt <- proc.time() - t0; store$cpu <- unname(tt["user.self"] + tt["sys.self"])
  store$acc_moves <- acc / pmax(tried, 1); store$tried <- tried; store$acc <- NA
  store
}
