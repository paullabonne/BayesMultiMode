# Efficiency: effective draws per CPU second (ESS from 10,000 stored draws per chain, CPU of the whole 100,000-iteration chain),
# median over 4 chains, for the log-likelihood and the number of modes.
S <- Sys.getenv("PILOT_R1_DIR", unset = getwd())
source(file.path(S, "snb_s2_sampler.R")); source(file.path(S, "s2_functions.R")); source(file.path(S, "NB_Comparisons.R"))
rd <- function(fs) Filter(Negate(is.null), lapply(fs, function(f) if (file.exists(f)) readRDS(f) else NULL))
row <- function(lab, ch) { if (!length(ch)) return(invisible())
  cpu <- sapply(ch, `[[`, "cpu"); el <- sapply(ch, function(x) nb_ess(x$loglik)); eL <- sapply(ch, function(x) nb_ess(x$L))
  cat(sprintf("  %-22s | CPU s/chain %4.0f | ESS log-lik %5.0f (%5.2f/s) | ESS modes %5.0f (%5.2f/s) | split Rhat log-lik %.2f\n",
    lab, median(cpu), median(el), median(el / cpu), median(eL), median(eL / cpu), split_rhat(lapply(ch, `[[`, "loglik")))) }
for (d in c("default", "inflation", "dna")) { cat(d, "\n")
  row("SFM, J = 10", rd(file.path(S, "res_pilot", sprintf("%s_ours_c%d.rds", d, 1:4))))
  if (d == "inflation") { row("SFM, J = 20", rd(file.path(S, "res_sfm20", sprintf("inflation_J20_c%d.rds", 1:4))))
    row("SFM, J = 20 (rerun)", rd(file.path(S, "res_pilot20", sprintf("inflation_ours_c%d.rds", 1:4)))) }
  row("Telescoping, dynamic", rd(file.path(S, "res_tele", sprintf("%s_r0_tsd_c%d.rds", d, 1:4))))
  row("Telescoping, static", rd(file.path(S, "res_tele", sprintf("%s_r0_tss_c%d.rds", d, 1:4))))
}
