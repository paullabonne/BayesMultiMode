# Three-way comparison: SFM (J = 10; J = 20 for inflation), telescoping (dynamic, static) and RJMCMC (static target).
S <- Sys.getenv("PILOT_R1_DIR", unset = getwd())
source(file.path(S, "snb_s2_sampler.R")); source(file.path(S, "s2_functions.R")); source(file.path(S, "NB_Comparisons.R"))
rd <- function(fs) Filter(Negate(is.null), lapply(fs, function(f) if (file.exists(f)) readRDS(f) else NULL))
top3 <- function(L) { t <- sort(table(L) / length(L), decreasing = TRUE)[1:min(3, length(unique(L)))]; paste(sprintf("%s:%.2f", names(t), t), collapse = " ") }
row <- function(lab, ch) { if (!length(ch)) return(invisible())
  L <- unlist(lapply(ch, `[[`, "L")); n <- min(sapply(ch, function(x) length(x$pr_mode))); pm <- Reduce(`+`, lapply(ch, function(x) x$pr_mode[1:n])) / length(ch)
  hi <- which(pm > .5) - 1; mid <- which(pm > .2 & pm <= .5) - 1
  cpu <- sapply(ch, `[[`, "cpu"); el <- sapply(ch, function(x) nb_ess(x$loglik)); eL <- sapply(ch, function(x) nb_ess(x$L))
  waic <- mean(sapply(ch, function(x) -2 * (x$lppd - x$pwaic)))
  Kp <- if (!is.null(ch[[1]]$Kplus)) median(unlist(lapply(ch, `[[`, "Kplus"))) else median(unlist(lapply(ch, `[[`, "K0")))
  acc <- if (!is.null(ch[[1]]$acc_moves)) paste0(" | moves acc ", paste(sprintf("%s %.3f", names(ch[[1]]$acc_moves), Reduce(`+`, lapply(ch, `[[`, "acc_moves")) / length(ch)), collapse = ", ")) else ""
  cat(sprintf("  %-14s | Pr(L) %s | modes %s%s | WAIC %.1f | Rhat %.2f | CPU/chain %4.0f | ESS/s log-lik %5.2f, modes %5.2f | K+ %g%s\n",
    lab, top3(L), paste(hi, collapse = ","), if (length(mid)) paste0(" [", paste(mid, collapse = ","), "]") else "", waic, split_rhat(lapply(ch, `[[`, "loglik")),
    median(cpu), median(el / cpu), median(eL / cpu), Kp, acc)) }
cat("REAL DATA (4 chains, 50,000 + 50,000, every 5th kept draw)\n")
for (d in c("default", "inflation", "dna")) { cat(d, "\n")
  row("SFM J=10", rd(file.path(S, "res_pilot", sprintf("%s_ours_c%d.rds", d, 1:4))))
  if (d == "inflation") row("SFM J=20", rd(file.path(S, "res_pilot20", sprintf("inflation_ours_c%d.rds", 1:4))))
  row("Telescoping d", rd(file.path(S, "res_tele", sprintf("%s_r0_tsd_c%d.rds", d, 1:4))))
  row("Telescoping s", rd(file.path(S, "res_tele", sprintf("%s_r0_tss_c%d.rds", d, 1:4))))
  row("RJMCMC", rd(file.path(S, "res_rj", sprintf("%s_r0_rj_c%d.rds", d, 1:4))))
}
cat("\nSIMULATED DATA (n = 2,000, data sets 1-3, chain 1, 50,000 + 50,000, every 25th kept draw)\n")
for (d in c("G1", "G4", "G5", "G6", "G7")) { g <- match(d, names(DESIGNS)); Lt <- length(DESIGNS[[g]]$modes)
  one <- function(lab, fs) { xs <- rd(fs); if (!length(xs)) return("")
    sprintf("%s: top %d/%d, Pr(true L) %.2f, TV %.3f, CPU %.0f", lab, sum(sapply(xs, function(x) as.numeric(names(which.max(table(x$L)))) == Lt)), length(xs),
      mean(sapply(xs, function(x) mean(x$L == Lt))), mean(sapply(xs, function(x) 0.5 * sum(abs(x$pmf - DESIGNS[[g]]$pmf)))), median(sapply(xs, function(x) if (!is.null(x$cpu)) x$cpu else x$secs))) }
  cat(sprintf(" %s | %s | %s | %s\n", d, one("SFM", file.path(S, "res_full", sprintf("%s_n2000_r%d_SNB_c1.rds", d, 1:3))),
    one("TSd", file.path(S, "res_tele", sprintf("%s_r%d_tsd_c1.rds", d, 1:3))), one("RJ", file.path(S, "res_rj", sprintf("%s_r%d_rj_c1.rds", d, 1:3)))))
}
