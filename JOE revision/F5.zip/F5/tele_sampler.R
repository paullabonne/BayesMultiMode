# Telescoping sampler (Fruhwirth-Schnatter, Malsiner-Walli and Grun, 2021, Algorithm 2 and Appendix C) for the
# mixture of shifted negative binomial distributions, with the number of components K unknown.
# Component updates are those of NB_Comparisons.R, algorithm "ours" (joint kappa step, r-tilde random walk,
# truncated Inverse-Gamma step for mu), with the same priors on (kappa_j, mu_j, r-tilde_j).
#   dynamic = TRUE : eta | K ~ Dir(alpha/K, ..., alpha/K), alpha ~ F(6, 3)            (their recommended set-up)
#   dynamic = FALSE: eta | K ~ Dir(gamma, ..., gamma),   gamma ~ Gamma(1, rate 200)    (static; same hyperprior as our SFM)
#   prior on K: K - 1 ~ BNB(1, 4, 3) (their recommendation), or uniform on {1, ..., Kmax}; truncated at Kmax.
# Requires NB_Comparisons.R (draw_kappa, draw_rtilde, draw_mu).
log_pK <- function(K, type = "bnb", Kmax = 30, a_l = 1, a_p = 4, b_p = 3) {
  if (type == "unif") return(ifelse(K <= Kmax, -log(Kmax), -Inf))
  lgamma(a_l + K - 1) + lbeta(a_l + a_p, K - 1 + b_p) - lgamma(a_l) - lgamma(K) - lbeta(a_p, b_p)
}
# log p(K | partition, hyperparameter) up to a constant, for K = Kp, ..., Kmax (eq. 5.3 dynamic; eq. 5.1 static)
log_K_post <- function(Ks, Nk, h, dynamic, ptype, Kmax) {
  Kp <- length(Nk); N <- sum(Nk)
  sapply(Ks, function(K) {
    g <- if (dynamic) h / K else h
    lp <- log_pK(K, ptype, Kmax) + lgamma(K + 1) - lgamma(K - Kp + 1) + lgamma(g * K) - lgamma(N + g * K) + sum(lgamma(Nk + g) - lgamma(g))
    lp })
}
# log p(h | partition, K) up to a constant, h = alpha (dynamic) or gamma (static)
log_h_post <- function(h, Nk, K, dynamic) {
  N <- sum(Nk); g <- if (dynamic) h / K else h
  lpr <- if (dynamic) df(h, 6, 3, log = TRUE) else dgamma(h, 1, rate = 200, log = TRUE)
  lpr + lgamma(g * K) - lgamma(N + g * K) + sum(lgamma(Nk + g) - lgamma(g))
}

ts_sampler <- function(y, burnin = 5000, nkeep = 10000, thin = 1, Kinit = 10, Kmax = 30, dynamic = TRUE, ptype = "bnb",
                       init = NULL, seed = NULL, h_step = 1) {
  if (!is.null(seed)) set.seed(seed)
  tab <- table(y); u <- as.numeric(names(tab)); cnt <- as.numeric(tab); m_u <- length(u); M <- max(y)
  K <- Kinit; kappa <- rep(0, K); rtilde <- rep(1 / 11, K); mu <- rep(max(mean(y), 1), K)
  if (!is.null(init)) { rtilde <- init$rtilde; kappa <- init$kappa }
  w <- rep(1 / K, K); sd1 <- rep(0.1, K); b1 <- n1 <- rep(0, K)
  h <- if (dynamic) 1 else 0.005
  nst <- floor(nkeep / thin)
  store <- list(mu = matrix(1, nst, Kmax), rtilde = matrix(0.1, nst, Kmax), kappa = matrix(0, nst, Kmax),
                w = matrix(0, nst, Kmax), nj = matrix(0, nst, Kmax), K = rep(NA, nst), Kplus = rep(NA, nst), h = rep(NA, nst))
  nuj <- NULL; n_batch <- 0; acc_h <- 0; t0 <- proc.time(); acc_r <- c(0, 0)
  for (it in 1:(burnin + nkeep)) {
    # Step 1: allocations (lambda integrated out), then keep only the filled components
    lp <- matrix(-Inf, m_u, K)
    for (j in 1:K) { id <- u >= kappa[j]; lp[id, j] <- log(w[j]) + dnbinom(u[id] - kappa[j], size = (1 - rtilde[j]) / rtilde[j], mu = mu[j], log = TRUE) }
    pr <- exp(lp - apply(lp, 1, max)); nuj <- matrix(0, m_u, K)
    for (i in 1:m_u) nuj[i, ] <- rmultinom(1, cnt[i], pr[i, ])
    nj <- colSums(nuj); f <- which(nj > 0); Kp <- length(f)
    nuj <- nuj[, f, drop = FALSE]; nj <- nj[f]; kappa <- kappa[f]; mu <- mu[f]; rtilde <- rtilde[f]; sd1 <- sd1[f]; b1 <- b1[f]; n1 <- n1[f]
    # Step 2: parameters of the filled components (as in NB_Comparisons.R, algorithm "ours")
    for (j in 1:Kp) {
      act <- nuj[, j] > 0; ua <- u[act]; na <- nuj[act, j]; r <- (1 - rtilde[j]) / rtilde[j]
      s <- draw_kappa(ua, na, kappa[j], mu[j], r, M); kappa[j] <- s$kappa; mu[j] <- s$mu
      ya <- ua - kappa[j]
      s <- draw_rtilde(ya, na, mu[j], rtilde[j], sd1[j]); rtilde[j] <- s$value
      b1[j] <- b1[j] + s$acc; n1[j] <- n1[j] + 1; if (it > burnin) acc_r <- acc_r + c(s$acc, 1)
      mu[j] <- draw_mu(ya, na, mu[j], (1 - rtilde[j]) / rtilde[j], M)
    }
    # Step 3: K given the partition, then the hyperparameter given the partition and K
    Ks <- Kp:Kmax; lk <- log_K_post(Ks, nj, h, dynamic, ptype, Kmax)
    K <- Ks[sample.int(length(Ks), 1, prob = exp(lk - max(lk)))]
    cand <- exp(log(h) + h_step * rnorm(1))
    if (log(runif(1)) < log_h_post(cand, nj, K, dynamic) - log_h_post(h, nj, K, dynamic) + log(cand) - log(h)) { h <- cand; if (it > burnin) acc_h <- acc_h + 1 }
    # Step 4: add K - K+ empty components from the prior, then the weights
    if (K > Kp) { ne <- K - Kp
      kappa <- c(kappa, sample.int(M + 1, ne, TRUE) - 1); mu <- c(mu, M * (1 - runif(ne))); rtilde <- c(rtilde, 0.5 * (1 - runif(ne)))
      sd1 <- c(sd1, rep(0.1, ne)); b1 <- c(b1, rep(0, ne)); n1 <- c(n1, rep(0, ne)) }
    e <- (if (dynamic) h / K else h) + c(nj, rep(0, K - Kp))
    g <- rgamma(K, e, 1); if (!all(is.finite(g)) || sum(g) == 0) g <- e + 1e-10; w <- g / sum(g)
    # adaptation of the r-tilde random-walk scales during burn-in (per filled component, as in NB_Comparisons.R)
    if (it <= burnin && it %% 50 == 0) {
      n_batch <- n_batch + 1; dl <- min(0.1, 1 / sqrt(n_batch))
      for (j in seq_along(sd1)) if (n1[j] > 0) { rt <- b1[j] / n1[j]; if (rt > 0.4) sd1[j] <- sd1[j] * exp(dl) else if (rt < 0.3) sd1[j] <- sd1[j] * exp(-dl) }
      b1[] <- 0; n1[] <- 0
    }
    if (it > burnin && (it - burnin) %% thin == 0) {
      i <- (it - burnin) / thin; kk <- seq_len(Kp)
      store$mu[i, kk] <- mu[kk]; store$rtilde[i, kk] <- rtilde[kk]; store$kappa[i, kk] <- kappa[kk]
      store$w[i, kk] <- w[kk] / sum(w[kk]); store$nj[i, kk] <- nj; store$K[i] <- K; store$Kplus[i] <- Kp; store$h[i] <- h
    }
  }
  tt <- proc.time() - t0; store$cpu <- unname(tt["user.self"] + tt["sys.self"])
  store$acc_h <- acc_h / nkeep; store$acc1 <- acc_r[1] / max(acc_r[2], 1); store$acc <- store$acc1
  store
}
