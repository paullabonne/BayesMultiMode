# Correctness check of the telescoping sampler: y = (0, 1, 7, 8). The exact posterior of K and K+ is computed by
# enumerating the 15 set partitions, with each cluster's marginal likelihood integrated numerically over the prior of
# (kappa, mu, r-tilde), and the hyperparameter integrated numerically; then compared with long sampler runs.
S <- Sys.getenv("PILOT_R1_DIR", unset = getwd())
source(file.path(S, "snb_s2_sampler.R")); source(file.path(S, "s2_functions.R")); source(file.path(S, "NB_Comparisons.R")); source(file.path(S, "tele_sampler.R"))
y <- c(0, 1, 7, 8); N <- length(y); M <- max(y); Kmax <- 30
# set partitions of 1..N as label vectors (restricted growth strings)
parts <- list(); rg <- function(v, k) { if (length(v) == N) { parts[[length(parts) + 1]] <<- v; return(invisible()) }
  for (c in 1:(k + 1)) rg(c(v, c), max(k, c)) }; rg(1, 1); stopifnot(length(parts) == 15)
# cluster marginal likelihood: kappa uniform on 0..M, mu ~ U(0, M], r-tilde ~ U(0, 1/2)
mg <- (seq_len(800) - 0.5) / 800 * M; rg2 <- (seq_len(400) - 0.5) / 400 * 0.5; R <- (1 - rg2) / rg2
marg <- function(yc) { tot <- 0
  for (k in 0:min(yc)) { L <- matrix(1, length(mg), length(rg2)); for (v in yc) L <- L * outer(mg, R, function(m, r) dnbinom(v - k, size = r, mu = m))
    tot <- tot + mean(L) / (M + 1) }; tot }
lm <- sapply(parts, function(p) sum(sapply(unique(p), function(c) log(marg(y[p == c])))))
Nk <- lapply(parts, function(p) as.numeric(table(p)))
hg <- exp(seq(log(1e-5), log(1e4), length.out = 4000)); dh <- c(diff(log(hg)), 0) * hg     # integrate over h on a log grid
exact <- function(dynamic) {
  lph <- if (dynamic) df(hg, 6, 3, log = TRUE) else dgamma(hg, 1, rate = 200, log = TRUE)
  P <- matrix(0, length(parts), Kmax)
  for (a in seq_along(parts)) { nk <- Nk[[a]]; Kp <- length(nk)
    for (K in Kp:Kmax) { g <- if (dynamic) hg / K else hg
      le <- lgamma(K + 1) - lgamma(K - Kp + 1) + lgamma(g * K) - lgamma(N + g * K) + rowSums(sapply(nk, function(n) lgamma(n + g) - lgamma(g)))
      P[a, K] <- exp(log_pK(K) + lm[a]) * sum(exp(le + lph) * dh) } }
  P <- P / sum(P); list(K = colSums(P), Kp = tapply(rowSums(P), sapply(Nk, length), sum)) }
for (dyn in c(TRUE, FALSE)) {
  ex <- exact(dyn)
  sims <- lapply(1:4, function(ch) { set.seed(100 + ch); ts_sampler(y, burnin = 5000, nkeep = 200000, Kinit = 10, Kmax = Kmax, dynamic = dyn, init = chain_init(y, 10, ch), seed = 100 + ch) })
  Ksim <- unlist(lapply(sims, `[[`, "K")); Kpsim <- unlist(lapply(sims, `[[`, "Kplus"))
  cat(sprintf("\n%s MFM: exact vs sampler (4 chains x 200,000)\n", if (dyn) "Dynamic" else "Static"))
  cat(" K+  :", sprintf("%d: %.4f vs %.4f", 1:4, ex$Kp[as.character(1:4)], sapply(1:4, function(k) mean(Kpsim == k))), "\n")
  cat(" K   :", sprintf("%d: %.4f vs %.4f", 1:8, ex$K[1:8], sapply(1:8, function(k) mean(Ksim == k))), "\n")
  cat(sprintf(" E(K): %.3f vs %.3f\n", sum((1:Kmax) * ex$K), mean(Ksim)))
}
